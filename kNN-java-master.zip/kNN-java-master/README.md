# kNN-java
**k-Nearest Neighbor (kNN) Algorithm in Java**

This is my implementation of k-Nearest Neighbor (kNN) Algorithm simulation which was written in Java language. The purpose of this implementation is to see how the algorithm works in a 2-dimensional plain space where several data objects are distributed randomly and there exists one query object which chooses its k nearest data objects by calculating Euclidean distances of all.

Actually, kNN can be encountered in Machine Learning as a classification algorithm. Here, however, it is applied for proximity querying.

The applet was created during my PhD Thesis study, which is about enhancing nearest neighbor query processing.

For this applet project, Java 8 SE JDK and NetBeans IDE 8.2 were used. However, I suppose there should not be any problems when executed on the latest Java and Apache NetBeans versions although I haven't tested yet.

## Example Screenshot

![kNN Applet Demo](https://i.ibb.co/vY9SZxS/KNN-applet-demo.png)

## Features

The Java applet executes the kNN very well and accurately on data objects (shown as black dots above) and the query object (shown as red dot above) is the main element for selecting the nearest data objects (shown as blue dots above) that is limited to k value. Moreover, a red query circle is drawn whose radius is determined by the distance of the furthest selected data object. Besides, this circle and k number of selected data objects are updated accordingly whenever the query object performs a movement as the applet allows it to do so.

Without closing and re-opening the applet, the user can perform several things:
* Random creation of new data objects and the query object altogether
* Movement of query object with four directions (left, right, up, down) to get different kNN output
* Showing the ID numbers of data objects
* Showing the coordinates of data objects and the query object (i.e. (X, Y))
* Showing the Euclidean distance of selected data objects in the console
* Adjusting the movement speed of the query object

Within the source code, horizontal and vertical length of the space, the number of data objects, k value, and the initial movement speed of the query object can be changed. (i.e. `Hsize`, `Vsize`, `dataObject`, `k`, and `speed`)

**Note:** To maintain the operability, it is guaranteed that data objects and the query object are always generated within the boundaries of the plain space and it is not possible to move the query object to the outside of the boundary.

## Usage

If loaded in NetBeans IDE, pressing F6 will start the applet. At the bottom, the user is informed to perform several actions with the press of the appropriate key.

* SPACE = Randomly create new objects (by randomizing the positions of all data objects and the query object)
* Arrow Keys = Move the query object left, right, up and down according to the current movement speed (indicated as px value)
* `+` = Increase the movement speed of the query object by 1 px (max limit 10)
* `-` = Decrease the movement speed of the query object by 1 px (min limit 1)
* A = Turn on/off the numbers of each data object
* S = Turn on/off the coordinates (X, Y) of each data object, including the query object
* D = Turn on/off the distances of selected data objects in the console

Within the source code, these variables are vital for the general operation of the kNN applet:
* `dataObject` = The number of data objects avaialble in the 2D space
* `Hsize` = Horizontal length of the 2D space
* `Vsize` = Vertical length of the 2D space
* `k` = The number of data objects to be chosen by the query object
* `speed` = The initial movement speed of the query object (as px value)

### Caution!

Inappropriate values must not be given in order not to come across weird experiments!

## Extended Experiments

An extended version of this applet is available, which extends the usability by the implementation of new features. [Click here](https://github.com/toUpperCase78/kNN-java-ExtExp) to inspect.
