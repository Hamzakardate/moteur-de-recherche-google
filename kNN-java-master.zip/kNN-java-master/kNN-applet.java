package myknnapp;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * @title K Nearest Neighbor Demonstration in Java
 * @author Yigit Newday (a.k.a. toUpperCase78)
 */
public class MyKNNApp {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        KNN knn1 = new KNN();
        frame.add(knn1);
        frame.setVisible(true);
        frame.setSize(knn1.Hsize+16, knn1.Vsize+90);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("K Nearest Neighbor Demo by Yigit Newday");
    }
}

class KNN extends JPanel implements KeyListener {
    boolean showCoords = false;
    boolean showNumbers = false;
    boolean showDistance = false;
    BufferedImage I;
    int px[], py[], qx, qy, dataObject = 40, Hsize = 800, Vsize = 600, k = 3, speed = 5;
    double dist[], shortestD[], shortestDmax;
    boolean isNearest[];
    Random rand = new Random();
    static Graphics2D g;
    
    public KNN(){
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(true);
        I = new BufferedImage(Hsize, Vsize, BufferedImage.TYPE_INT_RGB);
        px = new int[dataObject];
        py = new int[dataObject];
        dist = new double[dataObject];
        shortestD = new double[k];
        isNearest = new boolean[dataObject];
        g = I.createGraphics();
        createDataObjects();
        createQueryObject();
        calculateKNN();
        showObjects();
    }
    
    public void createDataObjects(){
        for(int i = 0; i < dataObject; i++){
            px[i] = 15 + rand.nextInt(Hsize-30);
            py[i] = 15 + rand.nextInt(Vsize-50);
        }
    }
    
    public void createQueryObject(){
        qx = 25 + rand.nextInt(Hsize-50);
        qy = 25 + rand.nextInt(Vsize-50);
    }
    
    public void calculateKNN(){     // Begin the distance calculations here
        for(int i = 0; i < dataObject; i++)
            isNearest[i] = false;   // Initialize the status of nearest for all data objects as false
        for(int a = 0; a < k; a++){
            double shortestDist = 999999.9;
            int n = 0;
            for(int i = 0; i < dataObject; i++){
                if(isNearest[i] == false){     // As long as it is not marked as true, include the data object for distance calculation
                    dist[i] = distance(px[i], qx, py[i], qy);
                    //System.out.println("i: " + i + "  (" + px[i] + ", " + py[i] + ")  dist: " + dist[i]);
                    if(dist[i] < shortestDist){
                        shortestDist = dist[i];
                        n = i;
                    }
                }
            }
            isNearest[n] = true;     // Mark the nearest data object as true
            shortestD[a] = shortestDist;    // Store the shortest distance value
        }
        shortestDmax = 0.0;     // Also, determine the maximum distance of all selected data object, for the radius of query range
        for(int a = 0; a < k; a++){
            if(shortestD[a] > shortestDmax)
                shortestDmax = shortestD[a];
        }
        if(showDistance){      // If showDistance is on, output the shortest distances on the console
            System.out.print("Shortest Dist.: [");
            for(int a = 0; a < k; a++){
                if(a != k-1)
                    System.out.printf("%.3f, ", shortestD[a]);
                else
                    System.out.printf("%.3f", shortestD[a]);
            }
            System.out.println("]");
        }
    }
    
    public double distance(int x1, int x2, int y1, int y2){    // The method which is responsible for performing distance calculations
        double d;
        d = Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)); // Euclidean distance
        return d;
    }
    
    public void showObjects(){     // Show all objects and drawings on the applet
        int shortestDm = (int) shortestDmax;
        for(int i = 0; i < Hsize; i++){
            for(int j = 0; j < Vsize; j++){
                I.setRGB(i, j, 16777215);
            }
        }             
        g.setColor(Color.RED);    // Show the query object
        g.fill(new Ellipse2D.Double(qx - 5, qy - 5, 10, 10));
        if(showCoords){
            if(qy > Vsize - 25 && qx > Hsize - 70)
                g.drawString("(" + qx + ", " + qy + ")", qx-55, qy-8);
            else if(qy > Vsize - 25)
                g.drawString("(" + qx + ", " + qy + ")", qx-5, qy-8);
            else if(qx > Hsize - 70)
                g.drawString("(" + qx + ", " + qy + ")", qx-55, qy+16);
            else
                g.drawString("(" + qx + ", " + qy + ")", qx-5, qy+16);
        }
        
        for(int i = 0; i < dataObject; i++){    // Show all data objects
            if(isNearest[i] == true){           // If the data object is marked as true, show it in blue color
                g.setColor(new Color(0, 125, 255));
                g.fill(new Ellipse2D.Double(px[i] - 3.5, py[i] - 3.5, 7, 7));
                g.drawLine(px[i], py[i], qx, qy);
            }
            else {
                g.setColor(Color.BLACK);        // Otherwise, show it in black color
                g.fill(new Ellipse2D.Double(px[i] - 3.5, py[i] - 3.5, 7, 7));
            }
            if(showCoords){        // If showCoords is on, output (x, y) coordinates of all data objects on the applet
                if(px[i] < Hsize - 70)
                    g.drawString("(" + px[i] + ", " + py[i] + ")", px[i]-5, py[i]+15);
                else
                    g.drawString("(" + px[i] + ", " + py[i] + ")", px[i]-55, py[i]+15);
            }
            if(showNumbers){       // If showNumbers is on, output data objects' numbers on the applet
                if(i < 9)
                    g.drawString(i+1 + "", px[i]-11, py[i]+2);
                else
                    g.drawString(i+1 + "", px[i]-18, py[i]+2);
            }
        }
        g.setColor(Color.red);     // Draw the query range circle
        g.drawOval(qx-shortestDm, qy-shortestDm, shortestDm*2, shortestDm*2);
    }
    
    public void paint(Graphics g){   // Show the strings at the bottom
        g.drawImage(I, 0, 0, this);
        g.setColor(new Color(210, 210, 210));
        g.fillRect(0, Vsize, Hsize, 60);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.BOLD, 16));
        g.drawString(k + "NN Demonstration", 20, Vsize + 20);
        g.setFont(new Font("Arial", Font.PLAIN, 16));
        g.drawString("SPACE = Create New    Arrow Keys = Move Query Object    + / - = Change Speed", 200, Vsize+20);
        g.drawString("A = Show Numbers   S = Show Coords   D = Show Distance", 200, Vsize+42);
        g.drawString("Speed = " + speed, 20, Vsize + 42);
    }
    
    public void setCoords(){
        showCoords = !showCoords;
    }
    
    public void setNumbers(){
        showNumbers = !showNumbers;
    }
    
    public void setDistance(){
        showDistance = !showDistance;
    }
    
    public void keyPressed(KeyEvent e){
        int code = e.getKeyCode();
        if(code == KeyEvent.VK_A){    // Show each data object's number
            setNumbers();
            showObjects();
            repaint();
        }
        if(code == KeyEvent.VK_S){    // Show each data object's coordinates
            setCoords();
            showObjects();
            repaint();
        }
        if(code == KeyEvent.VK_D){    // Show distances of all selected data objects on the console
            setDistance();
            if(showDistance)
                System.out.println("Distance output enabled.");
            else
                System.out.println("Distance output disabled.");
        }
        if(code == KeyEvent.VK_SPACE){    // Generate completely randomized new data objects and query object
            System.out.println("New data objects have been created.");
            createDataObjects();
            createQueryObject();
            calculateKNN();
            showObjects();
            repaint();
        }
        if(code == KeyEvent.VK_UP){    // Move the query object up
            if(qy > 0){
                qy -= speed;
                if(qy < 0)    qy = 0;
                calculateKNN();
                showObjects();
                repaint();
            }           
        }
        if(code == KeyEvent.VK_DOWN){    // Move the query object down
            if(qy < Vsize){
                qy += speed;
                if(qy > Vsize)    qy = Vsize;
                calculateKNN();
                showObjects();
                repaint();
            }
        }
        if(code == KeyEvent.VK_LEFT){    // Move the query object to the left
            if(qx > 0){
                qx -= speed;
                if(qx < 0)    qx = 0;
                calculateKNN();
                showObjects();
                repaint();
            }
        }
        if(code == KeyEvent.VK_RIGHT){    // Move the query object to the right
            if(qx < Hsize){
                qx += speed;
                if(qx > Hsize)    qx = Hsize;
                calculateKNN();
                showObjects();
                repaint();
            }
        }
        if(code == KeyEvent.VK_ADD){    // Increase the query object's movement speed
            if(speed < 10){
                speed += 1;
                System.out.println("Query object speed: " + speed);
            }
            repaint();
        }
        if(code == KeyEvent.VK_SUBTRACT){    // Decrease the query object's movement speed
            if(speed > 1){
                speed -= 1;
                System.out.println("Query object speed: " + speed);
            }
            repaint();
        }
    }
    
    public void keyReleased(KeyEvent e){}   
    public void keyTyped(KeyEvent e){}
}
